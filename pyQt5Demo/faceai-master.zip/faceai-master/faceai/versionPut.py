#coding=utf-8
#版本号输出类
import cv2
import dlib
import face_recognition
import keras
import tensorflow

print(cv2.__version__)  # 输出：3.4.1
print(dlib.__version__)  # 输出：19.8.1
print(face_recognition.__version__)  #输出：1.2.2

print(keras.__version__)  # 输出：2.1.6
print(tensorflow.VERSION)  # 输出：1.8.0

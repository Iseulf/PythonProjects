# 图片上色 #


安装scikit-image模块：scikit-image (a.k.a. skimage) 是一个图像处理和计算机视觉的算法集合。
>sudo pip3 install scikit-image  

